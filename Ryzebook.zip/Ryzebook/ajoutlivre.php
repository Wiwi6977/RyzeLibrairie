<div class="block">
                            <footer class="footer">
                                    <h2 class="heading-size">Ajouter un nouveau Livre !</h2>
                                    <div class="footer-contact-form">
                                        <form method ="post">
                                        <div class="field">
                                            <label class="label">nom du Livre </label>
                                                <div class="control">
                                                <input class="input" type="text" placeholder="nom ?" name ="name">
                                            </div>
                                    </div>
                                    <div class="field">
                                            <label class="label">Auteurs </label>
                                                <div class="control">
                                                <input class="input" type="text" placeholder="Auteurs ?" name="Aut">
                                            </div>
                                        </div>
                                        <div class="field">
                                            <label class="label">Editeurs </label>
                                                <div class="control">
                                                <input class="input" type="text" placeholder="Editeurs ?" name="Edi">
                                            </div>
                                        </div>
                                        <div class="field">
                                            <label class="label">genre</label>
                                                <div class="control">
                                                <input class="input" type="text" placeholder="genre ?"name="genre">
                                            </div>
                                        </div>
                                        </form>
                                        <button class="button is-link "id="send-email" >Enregistrer le new livre</button>
                                    </div>