  <!-- Header de la page -->
        
  <div class="block">
                <header class="header">
                    <a href="#" class="header-logo">RyzeLibrarie</a>
                        <nav class="header-menu">
                            <a href="intro.php">L'intro</a>
                            <a href="Acceuil.php">Accueil</a>
                            <a href="livres.php">Livres</a>
                            <a href="Formulaires.php">Formulaires des livres</a>

                        </nav>
                </header>
        
            </div>
            <!-- La bannière -->
            <div class="block">
                <div class="banner">
                    <img src="img\Book.jpg" alt="Bannière" class="banner-image">
                    <div class="banner-content">
                        <h1 class="title is-1">Une Experience Magique.</h1>
                        <h2 class="subtitle">It's me Ryze of League of Legends and I love Books.</h2>
                    </div>
                </div>
            </div>



