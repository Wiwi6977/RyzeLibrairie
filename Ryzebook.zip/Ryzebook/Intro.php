<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Déclariation du charset , la feuille de style , la partie compatible avec le téléphone , Ipad -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/intro.css">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Le titre  de l'onglet -->
    <title>RyzeLibrarie</title>
    <!-- Insertion du logo -->
    <link rel="shortcut icon" href="img/logo.jpg">
    
</head>
<body>
    <!-- La tête de la page -->
     <header id="showcase">
            <h1>RyzeLibrarie.</h1>
            <p>Bienvenue dans le Paradis des livres. </p>
            <a href="Acceuil.php" class="boutton">Accéder au Site.</a> <!-- Lien vers l'acceuil de notre site -->

    </header>
   
</body>
</html>