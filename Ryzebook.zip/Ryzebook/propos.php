  <!--Section : à Propos de -->
  <div class="block">
                    <h2 class="subtitle heading-size">A propos de </h2>
                        <div class="container about">
                                <div class="columns">
                                        <div class="column about-single-element">
                                        <i class="fas fa-glasses icon"></i>
                                            <p> 
                                            Salut à toi , Je suis Ryze , je serais le narrateur de ce site en quelque sorte. Qui suis-je ? Ahahaha , Trés bonne question , tu le seras si tu continues à lire les petits paragrapahes qui se trouvent juste à cotés :) !
                                            </p>
                                        </div>
                                        <div class="column about-single-element">
                                        <i class="fas fa-book icon"></i>
                                        <p>
                                            Bien , maintenant que tu es concentré sur ce paragraphe , je vais te raconter d'ou je viens. Bah en fait , je viens d'un jeu vidéo : League of Legends. Je suis pas très difficile à jouer , suffit de rouler sa tête contre le clavier pour pouvoir dire Pentakill. Mais ce n'est pas le sujet , j'aime bien lire aussi et les créateurs  du site, étants des fans ont eu cette idée de m'intégrer à leur site pour pouvoir faire un lien entre jeux et lecture.
                                        </p>
                                        </div>
                                        <div class="column about-single-element">
                                        <i class="fas fa-pen icon"></i>
                                        <p>
                                            Le site est simple , j'ai mis une base de donnée dans ce site ou est contenu tous les livres que j'ai lu , A toi de découvrir Le site à travers le menu de navigation qui se trouve là haut. Voilà tu sais tout , inutile de t'en dire plus vu que j'ai terminé.
                                        </p>
                                        </div>
                                        </div>
                                </div>
                        </div>
                </div>